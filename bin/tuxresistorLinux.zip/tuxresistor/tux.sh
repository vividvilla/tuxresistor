#
# Script to run the App
#

java -cp .:tuxresistor.jar tuxresistor.Main
